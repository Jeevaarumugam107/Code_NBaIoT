import os, json, warnings, sys, itertools
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon, friedmanchisquare, rankdata
from statsmodels.stats.multitest import multipletests

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
SEED = 42
rng = np.random.default_rng(SEED)

# ---- Group A: 10 classical models (5-fold CV) + proposed ensemble (5-fold nested CV) ----
classical_folds = pd.read_csv(os.path.join(RES_DIR, "tables", "T_classical_ml_fold_results.csv"))
proposed_folds = pd.read_csv(os.path.join(RES_DIR, "tables", "T_proposed_ensemble_nested_cv.csv"))
proposed_folds = proposed_folds.rename(columns={"ensemble_tag": "model"})
proposed_folds["model"] = "proposed_ensemble"

metric_cols = ["mcc", "f1_macro", "auroc_ovr_macro", "balanced_accuracy"]
common_cols = ["model", "fold"] + metric_cols
group_a = pd.concat([classical_folds[common_cols], proposed_folds[common_cols]], ignore_index=True)
models_a = sorted(group_a["model"].unique())
print("Group A models:", models_a)

# --- pairwise Wilcoxon signed-rank (paired across the 5 folds) for each metric ---
pairwise_rows = []
for metric in metric_cols:
    pivot = group_a.pivot(index="fold", columns="model", values=metric)
    for m1, m2 in itertools.combinations(models_a, 2):
        d = pivot[m1] - pivot[m2]
        if np.allclose(d, 0):
            stat, p = np.nan, 1.0
        else:
            try:
                stat, p = wilcoxon(pivot[m1], pivot[m2])
            except ValueError:
                stat, p = np.nan, np.nan
        pairwise_rows.append({"metric": metric, "model_a": m1, "model_b": m2,
                               "mean_a": pivot[m1].mean(), "mean_b": pivot[m2].mean(),
                               "wilcoxon_stat": stat, "wilcoxon_p": p})

pw_df = pd.DataFrame(pairwise_rows)
# Holm correction within each metric's family of tests
for metric in metric_cols:
    mask = pw_df["metric"] == metric
    pvals = pw_df.loc[mask, "wilcoxon_p"].fillna(1.0).values
    reject, p_adj, _, _ = multipletests(pvals, alpha=0.05, method="holm")
    pw_df.loc[mask, "wilcoxon_p_holm"] = p_adj
    pw_df.loc[mask, "reject_at_0.05_holm"] = reject
pw_df.to_csv(os.path.join(RES_DIR, "tables", "T_pairwise_wilcoxon.csv"), index=False)

n_folds = group_a["fold"].nunique()
exact_floor_p = 2 * (0.5 ** n_folds)  # smallest achievable two-sided exact p-value at n_folds paired obs
print(f"n_folds={n_folds}; Wilcoxon exact-test floor p-value ~= {exact_floor_p:.4f}")

# --- Friedman omnibus + average ranks ---
friedman_rows = []
rank_rows = []
for metric in metric_cols:
    pivot = group_a.pivot(index="fold", columns="model", values=metric)
    pivot = pivot[models_a]
    try:
        stat, p = friedmanchisquare(*[pivot[m].values for m in models_a])
    except ValueError:
        stat, p = np.nan, np.nan
    friedman_rows.append({"metric": metric, "friedman_stat": stat, "friedman_p": p,
                           "significant_at_0.05": (p < 0.05) if not np.isnan(p) else None})
    # average rank per model (lower rank = better, so rank descending values)
    ranks = pivot.apply(lambda row: rankdata(-row.values), axis=1, result_type="expand")
    ranks.columns = models_a
    avg_rank = ranks.mean(axis=0)
    for m in models_a:
        rank_rows.append({"metric": metric, "model": m, "avg_rank": avg_rank[m]})

friedman_df = pd.DataFrame(friedman_rows)
friedman_df.to_csv(os.path.join(RES_DIR, "tables", "T_friedman_omnibus.csv"), index=False)
rank_df = pd.DataFrame(rank_rows)
rank_df.to_csv(os.path.join(RES_DIR, "tables", "T_average_ranks.csv"), index=False)
print(friedman_df.to_string())

# --- bootstrap CIs + paired bootstrap significance on the HELD-OUT TEST set:
#     proposed ensemble vs the single best classical model ---
ens_npz = np.load(os.path.join(DATA_DIR, "proposed_ensemble_test_predictions.npz"))
y_true = ens_npz["y_true"]; ens_pred = ens_npz["pred"]; ens_proba = ens_npz["proba"]

base_test = pd.read_csv(os.path.join(RES_DIR, "tables", "T_base_models_test_metrics.csv"))
best_base_name = base_test.sort_values("mcc", ascending=False).iloc[0]["model"]
print(f"\nBest single base model on held-out test: {best_base_name}")

single_npz_path = os.path.join(DATA_DIR, f"dl_{best_base_name}_test_predictions.npz")
# base models are classical, not DL -- recover their test predictions via stage6b's saved artifacts instead
import joblib
MODELS_DIR = os.path.join(RES_DIR, "models")
scaler = joblib.load(os.path.join(MODELS_DIR, "scaler.joblib"))
df_full = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
sel = json.load(open(os.path.join(RES_DIR, "tables", "selected_features.json")))
feat_cols = sel["features"]; classes = sel["label_classes"]; n_classes = len(classes)
test_df = df_full[df_full["split_role"] == "held_out_test"].copy()
X_test = scaler.transform(test_df[feat_cols].values)
best_model = joblib.load(os.path.join(MODELS_DIR, f"base_{best_base_name}.joblib"))
proba_best = best_model.predict_proba(X_test)
mc = getattr(best_model, "classes_", np.arange(n_classes))
best_proba_full = np.zeros((len(y_true), n_classes))
for ci, c in enumerate(mc):
    best_proba_full[:, int(c)] = proba_best[:, ci]
best_pred = np.argmax(best_proba_full, axis=1)

from sklearn.metrics import matthews_corrcoef, f1_score

def bootstrap_metric(y_true, pred_a, pred_b, n_boot=2000):
    n = len(y_true)
    mcc_a, mcc_b, f1_a, f1_b, wins_mcc, wins_f1 = [], [], [], [], 0, 0
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        ma = matthews_corrcoef(y_true[idx], pred_a[idx])
        mb = matthews_corrcoef(y_true[idx], pred_b[idx])
        fa = f1_score(y_true[idx], pred_a[idx], average="macro")
        fb = f1_score(y_true[idx], pred_b[idx], average="macro")
        mcc_a.append(ma); mcc_b.append(mb); f1_a.append(fa); f1_b.append(fb)
        if ma > mb: wins_mcc += 1
        if fa > fb: wins_f1 += 1
    return {
        "mcc_a_mean": np.mean(mcc_a), "mcc_a_ci_lo": np.percentile(mcc_a, 2.5), "mcc_a_ci_hi": np.percentile(mcc_a, 97.5),
        "mcc_b_mean": np.mean(mcc_b), "mcc_b_ci_lo": np.percentile(mcc_b, 2.5), "mcc_b_ci_hi": np.percentile(mcc_b, 97.5),
        "f1_a_mean": np.mean(f1_a), "f1_a_ci_lo": np.percentile(f1_a, 2.5), "f1_a_ci_hi": np.percentile(f1_a, 97.5),
        "f1_b_mean": np.mean(f1_b), "f1_b_ci_lo": np.percentile(f1_b, 2.5), "f1_b_ci_hi": np.percentile(f1_b, 97.5),
        "p_mcc_a_beats_b": wins_mcc / n_boot, "p_f1_a_beats_b": wins_f1 / n_boot, "n_boot": n_boot
    }

boot_res = bootstrap_metric(y_true, ens_pred, best_pred)
boot_res["model_a"] = "proposed_ensemble"; boot_res["model_b"] = best_base_name
with open(os.path.join(RES_DIR, "tables", "T_bootstrap_test_comparison.json"), "w") as f:
    json.dump(boot_res, f, indent=2, default=float)
print("\nBootstrap comparison (proposed ensemble vs best single base model, held-out test):")
print(json.dumps(boot_res, indent=2, default=float))

print("\nStage 10 complete.")
