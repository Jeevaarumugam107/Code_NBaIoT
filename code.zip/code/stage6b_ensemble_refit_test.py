import os, json, time, warnings, sys
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC, LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
import xgboost as xgb
import lightgbm as lgb
import catboost as cb
import joblib

sys.path.insert(0, os.path.dirname(__file__))
from harness import compute_multiclass_metrics

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
MODELS_DIR = "/home/claude/iot_botnet_study/results/models"
os.makedirs(MODELS_DIR, exist_ok=True)
SEED = 42

def get_model(name, seed):
    if name == "logistic_regression":
        return LogisticRegression(max_iter=500, n_jobs=2, random_state=seed, class_weight="balanced")
    if name == "linear_svm":
        base = LinearSVC(max_iter=3000, random_state=seed, class_weight="balanced")
        return CalibratedClassifierCV(base, method="sigmoid", cv=3)
    if name == "rbf_svm":
        return SVC(kernel="rbf", probability=True, random_state=seed, class_weight="balanced")
    if name == "random_forest":
        return RandomForestClassifier(n_estimators=300, max_depth=18, n_jobs=2, random_state=seed, class_weight="balanced")
    if name == "extra_trees":
        return ExtraTreesClassifier(n_estimators=300, max_depth=18, n_jobs=2, random_state=seed, class_weight="balanced")
    if name == "xgboost":
        return xgb.XGBClassifier(n_estimators=300, max_depth=8, learning_rate=0.1, n_jobs=2,
                                  random_state=seed, eval_metric="mlogloss", tree_method="hist")
    if name == "lightgbm":
        return lgb.LGBMClassifier(n_estimators=300, num_leaves=63, random_state=seed,
                                   class_weight="balanced", verbosity=-1, n_jobs=2)
    if name == "catboost":
        return cb.CatBoostClassifier(iterations=300, depth=8, random_state=seed, verbose=False,
                                      auto_class_weights="Balanced", thread_count=2)
    if name == "histgradientboosting":
        return HistGradientBoostingClassifier(max_iter=300, max_depth=10, random_state=seed, class_weight="balanced")
    if name == "knn":
        return KNeighborsClassifier(n_neighbors=7, n_jobs=2)
    raise ValueError(name)

RBF_SVM_TRAIN_CAP = 12000
KNN_TRAIN_CAP = 40000

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
sel = json.load(open(os.path.join(RES_DIR, "tables", "selected_features.json")))
feat_cols = sel["features"]; classes = sel["label_classes"]; n_classes = len(classes)
le = LabelEncoder(); le.fit(classes)

trainval = df[df["split_role"] == "trainval"].copy()
test_df = df[df["split_role"] == "held_out_test"].copy()
y_tv = le.transform(trainval["label_type"].values)
y_test = le.transform(test_df["label_type"].values)

cfg = json.load(open(os.path.join(RES_DIR, "tables", "proposed_ensemble_config.json")))
base_models = cfg["base_models"]
print("Refitting base models on full trainval:", base_models)

scaler = RobustScaler().fit(trainval[feat_cols].values)
X_train_full = scaler.transform(trainval[feat_cols].values)
X_test = scaler.transform(test_df[feat_cols].values)
joblib.dump(scaler, os.path.join(MODELS_DIR, "scaler.joblib"))

rng = np.random.default_rng(SEED)
test_proba_by_model = {}
timing = []
fitted_models = {}

for name in base_models:
    X_use, y_use = X_train_full, y_tv
    if name == "rbf_svm" and len(y_tv) > RBF_SVM_TRAIN_CAP:
        idx = rng.choice(len(y_tv), size=RBF_SVM_TRAIN_CAP, replace=False)
        X_use, y_use = X_train_full[idx], y_tv[idx]
    if name == "knn" and len(y_tv) > KNN_TRAIN_CAP:
        idx = rng.choice(len(y_tv), size=KNN_TRAIN_CAP, replace=False)
        X_use, y_use = X_train_full[idx], y_tv[idx]

    model = get_model(name, SEED)
    t0 = time.time()
    model.fit(X_use, y_use)
    fit_time = time.time() - t0

    t0 = time.time()
    proba_pred = model.predict_proba(X_test)
    infer_time = time.time() - t0
    model_classes = getattr(model, "classes_", np.arange(n_classes))
    proba_full = np.zeros((len(y_test), n_classes))
    for ci, c in enumerate(model_classes):
        proba_full[:, int(c)] = proba_pred[:, ci]
    test_proba_by_model[name] = proba_full
    fitted_models[name] = model
    timing.append({"model": name, "fit_time_s": fit_time, "infer_time_s": infer_time,
                    "n_train": len(y_use), "infer_ms_per_1000_rows": infer_time / len(y_test) * 1000 * 1000})
    joblib.dump(model, os.path.join(MODELS_DIR, f"base_{name}.joblib"))
    print(f"{name}: fit={fit_time:.1f}s infer={infer_time:.2f}s")

pd.DataFrame(timing).to_csv(os.path.join(RES_DIR, "tables", "T_proposed_ensemble_refit_timing.csv"), index=False)

# meta-learner refit on FULL OOF probability matrix (leakage-safe: OOF probs were produced by
# models that never saw that row during their own training in stage 4)
npz = np.load(os.path.join(DATA_DIR, "classical_oof.npz"))
X_stack_train = np.concatenate([npz[f"proba_{m}"] for m in base_models], axis=1)
meta = LogisticRegression(max_iter=1000, C=1.0, random_state=SEED)  # sklearn>=1.5: lbfgs is multinomial by default
meta.fit(X_stack_train, npz["y_true"])
joblib.dump(meta, os.path.join(MODELS_DIR, "meta_learner.joblib"))

X_stack_test = np.concatenate([test_proba_by_model[m] for m in base_models], axis=1)
t0 = time.time()
meta_proba_pred = meta.predict_proba(X_stack_test)
meta_infer_time = time.time() - t0
proba_final = np.zeros((len(y_test), n_classes))
for ci, c in enumerate(meta.classes_):
    proba_final[:, int(c)] = meta_proba_pred[:, ci]
pred_final = np.argmax(proba_final, axis=1)

m = compute_multiclass_metrics(y_test, pred_final, proba_final, n_classes)
m["model"] = "proposed_ensemble"
m["base_models"] = "+".join(base_models)
total_infer_ms_per_1000 = sum(t["infer_ms_per_1000_rows"] for t in timing) + (meta_infer_time / len(y_test) * 1000 * 1000)
m["infer_ms_per_1000_rows"] = total_infer_ms_per_1000
print("\n=== PROPOSED ENSEMBLE -- HELD-OUT TEST ===")
print(json.dumps(m, indent=2, default=str))

with open(os.path.join(RES_DIR, "tables", "proposed_ensemble_test_metrics.json"), "w") as f:
    json.dump(m, f, indent=2, default=str)

np.savez_compressed(os.path.join(DATA_DIR, "proposed_ensemble_test_predictions.npz"),
                     y_true=y_test, pred=pred_final, proba=proba_final)

# also score every individual base model on the held-out test set, for the results table
single_test_metrics = []
for name, proba in test_proba_by_model.items():
    pred = np.argmax(proba, axis=1)
    mm = compute_multiclass_metrics(y_test, pred, proba, n_classes)
    mm["model"] = name
    single_test_metrics.append(mm)
pd.DataFrame(single_test_metrics).to_csv(os.path.join(RES_DIR, "tables", "T_base_models_test_metrics.csv"), index=False)

print("\nStage 6b complete: models saved to results/models/, test metrics saved.")
