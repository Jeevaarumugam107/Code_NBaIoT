import os, json, warnings, sys
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
FIG_DIR = "/home/claude/iot_botnet_study/results/figures"
os.makedirs(FIG_DIR, exist_ok=True)

# ---------------- FINAL_METRICS: unified schema across classical + DL + proposed ensemble ----------------
classical_summary = pd.read_csv(os.path.join(RES_DIR, "tables", "T_classical_ml_summary.csv"))
classical_summary["model_family"] = "classical_ml"
classical_summary["evaluation_design"] = "5-fold_CV_block_disjoint"

dl_results = pd.read_csv(os.path.join(RES_DIR, "tables", "T_deep_learning_results.csv"))
dl_results["model_family"] = "deep_learning"
dl_results["evaluation_design"] = "single_block_disjoint_train_val_test_split"
dl_results = dl_results.rename(columns={"mcc": "mcc_mean", "f1_macro": "f1_mean",
                                         "auroc_ovr_macro": "auroc_mean", "accuracy": "accuracy_mean",
                                         "balanced_accuracy": "balanced_accuracy_mean",
                                         "precision_macro": "precision_mean", "recall_macro": "recall_mean",
                                         "auprc_ovr_macro": "auprc_mean", "log_loss": "logloss_mean",
                                         "brier_score": "brier_mean"})

proposed_nested = pd.read_csv(os.path.join(RES_DIR, "tables", "T_proposed_ensemble_nested_cv.csv"))
proposed_summary = proposed_nested.drop(columns=["fold", "ensemble_tag"]).mean(numeric_only=True).to_frame().T
proposed_summary_std = proposed_nested.drop(columns=["fold", "ensemble_tag"]).std(numeric_only=True)
proposed_summary["model"] = "proposed_ensemble"
proposed_summary["model_family"] = "proposed_ensemble"
proposed_summary["evaluation_design"] = "nested_5-fold_CV_block_disjoint"
proposed_summary = proposed_summary.rename(columns={"mcc": "mcc_mean", "f1_macro": "f1_mean",
                                                      "auroc_ovr_macro": "auroc_mean", "accuracy": "accuracy_mean",
                                                      "balanced_accuracy": "balanced_accuracy_mean",
                                                      "precision_macro": "precision_mean", "recall_macro": "recall_mean",
                                                      "auprc_ovr_macro": "auprc_mean", "log_loss": "logloss_mean",
                                                      "brier_score": "brier_mean"})
for k, v in proposed_summary_std.items():
    colmap = {"mcc": "mcc_std", "f1_macro": "f1_std", "auroc_ovr_macro": "auroc_std",
              "accuracy": "accuracy_std", "balanced_accuracy": "balanced_accuracy_std"}
    if k in colmap:
        proposed_summary[colmap[k]] = v

keep_cols = ["model", "model_family", "evaluation_design", "accuracy_mean", "precision_mean",
             "recall_mean", "f1_mean", "balanced_accuracy_mean", "mcc_mean", "mcc_std",
             "auroc_mean", "auroc_std", "auprc_mean", "logloss_mean", "brier_mean"]
for c in keep_cols:
    if c not in classical_summary.columns: classical_summary[c] = np.nan
    if c not in dl_results.columns: dl_results[c] = np.nan
    if c not in proposed_summary.columns: proposed_summary[c] = np.nan

final_metrics = pd.concat([classical_summary[keep_cols], dl_results[keep_cols], proposed_summary[keep_cols]],
                           ignore_index=True)
final_metrics = final_metrics.sort_values("mcc_mean", ascending=False)
final_metrics.to_csv(os.path.join(RES_DIR, "tables", "FINAL_METRICS.csv"), index=False)
print("=== FINAL_METRICS (all models, sorted by MCC) ===")
print(final_metrics.to_string())

# ---------------- FINAL_ABLATION ----------------
ablation = pd.read_csv(os.path.join(RES_DIR, "tables", "T_ablation_study.csv"))
ablation.to_csv(os.path.join(RES_DIR, "tables", "FINAL_ABLATION.csv"), index=False)

# ---------------- FINAL_ROBUSTNESS ----------------
robust = pd.read_csv(os.path.join(RES_DIR, "tables", "T_robustness.csv"))
cross_dev = pd.read_csv(os.path.join(RES_DIR, "tables", "T_cross_device_generalization.csv"))
cross_scn = pd.read_csv(os.path.join(RES_DIR, "tables", "T_cross_scenario_generalization.csv"))
final_robust = pd.concat([robust, cross_dev, cross_scn], ignore_index=True)
final_robust.to_csv(os.path.join(RES_DIR, "tables", "FINAL_ROBUSTNESS.csv"), index=False)

# ---------------- FINAL_STATISTICS ----------------
pw = pd.read_csv(os.path.join(RES_DIR, "tables", "T_pairwise_wilcoxon.csv"))
pw.to_csv(os.path.join(RES_DIR, "tables", "FINAL_STATISTICS_pairwise.csv"), index=False)
friedman = pd.read_csv(os.path.join(RES_DIR, "tables", "T_friedman_omnibus.csv"))
ranks = pd.read_csv(os.path.join(RES_DIR, "tables", "T_average_ranks.csv"))

# ---------------- computational complexity ----------------
timing_classical = pd.read_csv(os.path.join(RES_DIR, "tables", "T_classical_ml_timing.csv"))
timing_summary = timing_classical.groupby("model").agg(
    mean_fit_time_s=("fit_time_s", "mean"), mean_infer_time_s=("infer_time_s", "mean"),
    n_train_mean=("n_train", "mean")).reset_index()
timing_summary.to_csv(os.path.join(RES_DIR, "tables", "FINAL_COMPLEXITY.csv"), index=False)
print("\n=== Complexity (mean fit/infer time per model) ===")
print(timing_summary.to_string())

# ================= FIGURES =================
inv = pd.read_csv(os.path.join(RES_DIR, "tables", "dataset_inventory.csv"))

# F01: dataset population size per device (full population, log scale)
dev_totals = inv.groupby("device")["n_rows_full"].sum().sort_values()
plt.figure(figsize=(8, 5))
plt.barh(dev_totals.index, dev_totals.values, color="#55A868")
plt.xlabel("Total rows in full population (all classes)")
plt.title("N-BaIoT: full-population row counts by device")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_dataset_distribution.png"), dpi=150)
plt.close()

# F02: sampled class distribution
with open(os.path.join(RES_DIR, "tables", "dataset_eda_summary.json")) as f:
    eda = json.load(f)
fam = eda["class_balance_family"]
plt.figure(figsize=(6, 5))
plt.bar(fam.keys(), fam.values(), color=["#4C72B0", "#DD8452", "#55A868"])
plt.ylabel("Sampled row count")
plt.title("Sampled class balance (family level)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_class_distribution.png"), dpi=150)
plt.close()

# F: feature-count sweep (multiclass)
sweep = pd.read_csv(os.path.join(RES_DIR, "tables", "T_feature_count_sweep_multiclass.csv"))
fig, ax1 = plt.subplots(figsize=(7, 5))
ax1.plot(sweep["k_features"], sweep["mcc"], "o-", color="#4C72B0", label="MCC")
ax1.set_xlabel("Number of selected features (K)")
ax1.set_ylabel("MCC", color="#4C72B0")
ax2 = ax1.twinx()
ax2.plot(sweep["k_features"], sweep["fit_time_s"], "s--", color="#C44E52", label="Fit time (s)")
ax2.set_ylabel("Fit time (s)", color="#C44E52")
plt.title("Feature-count sweep: performance vs. compute cost")
fig.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_feature_count_sweep.png"), dpi=150)
plt.close()

# F: classical ML MCC comparison bar chart (with proposed ensemble)
plt.figure(figsize=(9, 6))
plot_df = final_metrics[final_metrics["model_family"].isin(["classical_ml", "proposed_ensemble"])].sort_values("mcc_mean")
colors = ["#C44E52" if m == "proposed_ensemble" else "#4C72B0" for m in plot_df["model"]]
plt.barh(plot_df["model"], plot_df["mcc_mean"], xerr=plot_df["mcc_std"], color=colors)
plt.xlabel("MCC (mean +/- std across folds)")
plt.title("Classical ML models vs. proposed ensemble (MCC)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_MCC_comparison.png"), dpi=150)
plt.close()

# F: deep learning MCC comparison
plt.figure(figsize=(8, 5))
dl_plot = dl_results.sort_values("mcc_mean")
plt.barh(dl_plot["model"], dl_plot["mcc_mean"], color="#8172B2")
plt.xlabel("MCC (held-out test)")
plt.title("Deep learning architectures (MCC, held-out test)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_DL_MCC_comparison.png"), dpi=150)
plt.close()

# F: ablation ladder
ablation_plot = ablation.copy()
plt.figure(figsize=(9, 5))
plt.plot(range(len(ablation_plot)), ablation_plot["mcc"], "o-", color="#4C72B0")
plt.xticks(range(len(ablation_plot)), ablation_plot["stage"], rotation=60, ha="right", fontsize=7)
plt.ylabel("MCC")
plt.title("Ablation ladder (A -> I)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_ablation_performance.png"), dpi=150)
plt.close()

# F: noise robustness (RF vs proposed ensemble)
noise = robust[robust["category"].isin(["noise_injection_RF", "noise_injection_proposed_ensemble"])].copy()
noise["noise_pct"] = noise["condition"].str.extract(r"(\d+)%").astype(float)
plt.figure(figsize=(7, 5))
for cat, grp in noise.groupby("category"):
    grp = grp.sort_values("noise_pct")
    plt.plot(grp["noise_pct"], grp["mcc"], "o-", label=cat)
plt.xlabel("Gaussian noise (% of feature std)")
plt.ylabel("MCC")
plt.legend()
plt.title("Noise robustness: single RF vs. proposed ensemble")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_noise_robustness.png"), dpi=150)
plt.close()

# F: cross-device generalization
cross_dev_sorted = cross_dev.sort_values("mcc")
plt.figure(figsize=(8, 5))
plt.barh(cross_dev_sorted["condition"].str.replace("held-out device: ", ""), cross_dev_sorted["mcc"], color="#DD8452")
plt.xlabel("MCC (held-out device)")
plt.title("Cross-device generalization (leave-one-device-out)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_cross_device_generalization.png"), dpi=150)
plt.close()

# F: cross-scenario (zero-day) generalization
cross_scn_sorted = cross_scn.sort_values("unseen_category_flagged_as_attack_rate")
plt.figure(figsize=(8, 5))
plt.barh(cross_scn_sorted["condition"].str.replace("held-out attack category: ", ""),
         cross_scn_sorted["unseen_category_flagged_as_attack_rate"], color="#55A868")
plt.xlabel("Fraction of unseen attack subtype flagged as non-benign")
plt.title("Zero-day generalization (leave-one-attack-type-out)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_cross_scenario_generalization.png"), dpi=150)
plt.close()

print("\nAll figures saved to", FIG_DIR)
print("\nStage 11 complete. Pipeline finished end-to-end.")
