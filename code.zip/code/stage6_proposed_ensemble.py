import os, json, time, warnings, sys, itertools
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import RobustScaler, LabelEncoder
from sklearn.model_selection import GroupKFold

sys.path.insert(0, os.path.dirname(__file__))
from harness import compute_multiclass_metrics

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
SEED = 42

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
sel = json.load(open(os.path.join(RES_DIR, "tables", "selected_features.json")))
feat_cols = sel["features"]; classes = sel["label_classes"]; n_classes = len(classes)
le = LabelEncoder(); le.fit(classes)

trainval = df[df["split_role"] == "trainval"].copy()
test_df = df[df["split_role"] == "held_out_test"].copy()
y_tv = le.transform(trainval["label_type"].values)
y_test = le.transform(test_df["label_type"].values)
cv_fold = trainval["cv_fold"].values

npz = np.load(os.path.join(DATA_DIR, "classical_oof.npz"))
MODEL_NAMES = ["logistic_regression", "linear_svm", "rbf_svm", "random_forest", "extra_trees",
               "xgboost", "lightgbm", "catboost", "histgradientboosting", "knn"]
oof_proba = {m: npz[f"proba_{m}"] for m in MODEL_NAMES}
oof_pred = {m: npz[f"pred_{m}"] for m in MODEL_NAMES}
y_true_oof = npz["y_true"]
assert np.array_equal(y_true_oof, y_tv)

# per-model OOF MCC (for reference / seeding diversity selection)
from sklearn.metrics import matthews_corrcoef
single_mcc = {m: matthews_corrcoef(y_tv, oof_pred[m]) for m in MODEL_NAMES}
print("Single-model OOF MCC:", {k: round(v, 4) for k, v in sorted(single_mcc.items(), key=lambda x: -x[1])})

# pairwise diversity: disagreement rate between OOF predictions (1 - agreement).
# Higher disagreement = more diverse. This is our diversity measure (simple, well-established
# alternative to Yule's Q for the multiclass setting, where Q's binary formulation does not apply).
def disagreement(a, b):
    return np.mean(oof_pred[a] != oof_pred[b])

pairs = list(itertools.combinations(MODEL_NAMES, 2))
div_rows = [{"model_a": a, "model_b": b, "disagreement": disagreement(a, b),
             "mcc_a": single_mcc[a], "mcc_b": single_mcc[b]} for a, b in pairs]
div_df = pd.DataFrame(div_rows).sort_values("disagreement", ascending=False)
div_df.to_csv(os.path.join(RES_DIR, "tables", "T_pairwise_diversity.csv"), index=False)
print(div_df.head(10).to_string())

def fit_meta_and_eval(base_models, oof_proba_dict, y_true_oof, cv_fold_arr, tag):
    """Nested-CV evaluation of a stacking ensemble over `base_models`: for each outer fold,
    the meta-learner is fit on the OOF base-probabilities of the OTHER folds and evaluated on
    the held-out fold's OOF base-probabilities. Because each base model's OOF probabilities are
    themselves already out-of-fold w.r.t. that base model's own training, this gives a fair,
    leakage-safe nested estimate of stacking performance without needing to refit base models."""
    X_stack = np.concatenate([oof_proba_dict[m] for m in base_models], axis=1)
    fold_metrics = []
    fold_ids = sorted(np.unique(cv_fold_arr))
    for fold in fold_ids:
        val_mask = cv_fold_arr == fold
        tr_mask = ~val_mask
        meta = LogisticRegression(max_iter=1000, C=1.0, random_state=SEED)  # sklearn>=1.5: lbfgs is multinomial by default
        meta.fit(X_stack[tr_mask], y_true_oof[tr_mask])
        proba = np.zeros((val_mask.sum(), n_classes))
        mp = meta.predict_proba(X_stack[val_mask])
        for ci, c in enumerate(meta.classes_):
            proba[:, int(c)] = mp[:, ci]
        pred = np.argmax(proba, axis=1)
        m = compute_multiclass_metrics(y_true_oof[val_mask], pred, proba, n_classes)
        m["fold"] = int(fold); m["ensemble_tag"] = tag
        fold_metrics.append(m)
    return pd.DataFrame(fold_metrics)

# --- Strategy 1: naive top-K by single-model MCC ---
K = 4
naive_topk = sorted(MODEL_NAMES, key=lambda m: -single_mcc[m])[:K]
print(f"\nNaive top-{K} by MCC:", naive_topk)
naive_results = fit_meta_and_eval(naive_topk, oof_proba, y_tv, cv_fold, "naive_topK")

# --- Strategy 2: greedy diversity-driven selection, seeded from the best standalone model ---
seed_model = max(single_mcc, key=single_mcc.get)
selected = [seed_model]
remaining = [m for m in MODEL_NAMES if m != seed_model]
while len(selected) < K:
    best_cand, best_score = None, -1
    for cand in remaining:
        avg_disagreement = np.mean([disagreement(cand, s) for s in selected])
        # combine diversity with standalone competence so we don't select a diverse-but-useless model
        score = 0.6 * avg_disagreement + 0.4 * single_mcc[cand]
        if score > best_score:
            best_score, best_cand = score, cand
    selected.append(best_cand)
    remaining.remove(best_cand)
print(f"Diversity-driven selection (seed={seed_model}):", selected)
diverse_results = fit_meta_and_eval(selected, oof_proba, y_tv, cv_fold, "diversity_driven")

comparison = pd.concat([naive_results, diverse_results], ignore_index=True)
comparison.to_csv(os.path.join(RES_DIR, "tables", "T_ensemble_selection_comparison.csv"), index=False)
print("\nNaive top-K mean MCC:", naive_results["mcc"].mean(), "+/-", naive_results["mcc"].std())
print("Diversity-driven mean MCC:", diverse_results["mcc"].mean(), "+/-", diverse_results["mcc"].std())

# pick whichever wins on mean MCC as "the proposed ensemble" base-model set
final_base_models = selected if diverse_results["mcc"].mean() >= naive_results["mcc"].mean() else naive_topk
selection_strategy = "diversity_driven" if final_base_models == selected else "naive_topK"
print(f"\nFinal proposed base models ({selection_strategy}):", final_base_models)

proposed_nested = fit_meta_and_eval(final_base_models, oof_proba, y_tv, cv_fold, "proposed_ensemble")
proposed_nested.to_csv(os.path.join(RES_DIR, "tables", "T_proposed_ensemble_nested_cv.csv"), index=False)
print("\nProposed ensemble nested-CV metrics (mean over 5 folds):")
print(proposed_nested.drop(columns=["fold", "ensemble_tag"]).mean(numeric_only=True))

with open(os.path.join(RES_DIR, "tables", "proposed_ensemble_config.json"), "w") as f:
    json.dump({"base_models": final_base_models, "selection_strategy": selection_strategy,
               "seed_model": seed_model, "K": K}, f, indent=2)

print("\nStage 6a (selection + nested-CV) complete. Run stage6b to refit on full data and score held-out test.")
