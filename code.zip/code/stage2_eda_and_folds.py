import os
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit, StratifiedGroupKFold

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
SEED = 42

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_raw.pkl"))
meta_cols = ["device", "source_path", "label_binary", "label_family", "label_type", "block_id"]
feat_cols = [c for c in df.columns if c not in meta_cols]
print("N feature columns:", len(feat_cols))
print("N rows:", len(df))

# --- EDA summary ---
eda = {}
eda["n_rows"] = len(df)
eda["n_features"] = len(feat_cols)
eda["n_devices"] = df["device"].nunique()
eda["n_blocks"] = df["block_id"].nunique()
eda["class_balance_binary"] = df["label_binary"].value_counts().to_dict()
eda["class_balance_family"] = df["label_family"].value_counts().to_dict()
eda["duplicate_rows_exact"] = int(df[feat_cols].duplicated().sum())
eda["zero_variance_features"] = list(df[feat_cols].columns[df[feat_cols].nunique() <= 1])
desc = df[feat_cols].describe().T
desc.to_csv(os.path.join(RES_DIR, "tables", "T_feature_descriptive_stats.csv"))

# near-duplicate check *within* a block vs *across* blocks (relevant to leakage risk)
dup_mask = df[feat_cols].duplicated(keep=False)
dup_sub = df.loc[dup_mask, ["block_id"] + feat_cols]
dup_groups = dup_sub.groupby(feat_cols)["block_id"].nunique()
eda["duplicate_groups_spanning_gt1_block"] = int((dup_groups > 1).sum())
eda["duplicate_groups_total"] = int(len(dup_groups))

import json
with open(os.path.join(RES_DIR, "tables", "dataset_eda_summary.json"), "w") as f:
    json.dump(eda, f, indent=2, default=str)
print(json.dumps(eda, indent=2, default=str)[:2000])

# --- correlation among features (for redundancy pruning later) ---
corr = df[feat_cols].corr()
corr.to_csv(os.path.join(RES_DIR, "tables", "T_feature_correlation_matrix.csv"))
high_corr_pairs = []
cols = corr.columns
arr = corr.values
n = len(cols)
for i in range(n):
    for j in range(i+1, n):
        v = arr[i, j]
        if abs(v) >= 0.98:
            high_corr_pairs.append((cols[i], cols[j], float(v)))
print(f"Feature pairs with |corr| >= 0.98: {len(high_corr_pairs)} out of {n*(n-1)//2} total pairs")
pd.DataFrame(high_corr_pairs, columns=["feat_a", "feat_b", "corr"]).to_csv(
    os.path.join(RES_DIR, "tables", "T_high_correlation_pairs.csv"), index=False)

# --- block-disjoint outer split: 80% train+cv pool / 20% held-out test, grouped by block_id ---
groups = df["block_id"].values
y_bin = (df["label_binary"] == "attack").astype(int).values

gss = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=SEED)
trainval_idx, test_idx = next(gss.split(df, y_bin, groups=groups))

df["split_role"] = "trainval"
df.loc[df.index[test_idx], "split_role"] = "held_out_test"

# 5-fold grouped CV on the trainval pool, stratified by binary label at the block level
trainval_df = df.iloc[trainval_idx]
sgkf = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)
fold_assign = np.full(len(df), -1, dtype=int)
tv_groups = trainval_df["block_id"].values
tv_y = (trainval_df["label_binary"] == "attack").astype(int).values
for fold_i, (_, val_idx) in enumerate(sgkf.split(trainval_df, tv_y, groups=tv_groups)):
    global_idx = trainval_df.index[val_idx]
    fold_assign[df.index.get_indexer(global_idx)] = fold_i

df["cv_fold"] = fold_assign  # -1 for held_out_test rows

# sanity: verify no block_id appears in more than one fold / role
check = df.groupby("block_id").agg(n_roles=("split_role", "nunique"), n_folds=("cv_fold", "nunique"))
assert (check["n_roles"] == 1).all(), "LEAKAGE: a block_id spans both trainval and held_out_test"
assert (check["n_folds"] == 1).all(), "LEAKAGE: a block_id spans more than one CV fold"
print("Block-disjointness verified: no block_id crosses split_role or cv_fold boundaries.")

print(df["split_role"].value_counts())
print(df.loc[df["split_role"]=="trainval", "cv_fold"].value_counts().sort_index())

df.to_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
with open(os.path.join(RES_DIR, "tables", "feature_columns.json"), "w") as f:
    json.dump(feat_cols, f)
print("Saved sampled_with_folds.pkl and feature_columns.json")
