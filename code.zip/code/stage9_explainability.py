import os, json, warnings, sys
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import shap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
FIG_DIR = "/home/claude/iot_botnet_study/results/figures"
os.makedirs(FIG_DIR, exist_ok=True)
SEED = 42
rng = np.random.default_rng(SEED)

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
sel = json.load(open(os.path.join(RES_DIR, "tables", "selected_features.json")))
feat_cols = sel["features"]; classes = sel["label_classes"]; n_classes = len(classes)
le = LabelEncoder(); le.fit(classes)

trainval = df[df["split_role"] == "trainval"].copy()
val_mask = trainval["cv_fold"].values == 0
train_mask = ~val_mask
y_tv = le.transform(trainval["label_type"].values)
y_train = y_tv[train_mask]; y_val = y_tv[val_mask]

scaler = RobustScaler().fit(trainval.loc[train_mask, feat_cols].values)
X_train = scaler.transform(trainval.loc[train_mask, feat_cols].values)
X_val = scaler.transform(trainval.loc[val_mask, feat_cols].values)

rf = RandomForestClassifier(n_estimators=200, max_depth=16, n_jobs=2, random_state=SEED, class_weight="balanced")
rf.fit(X_train, y_train)

# SHAP on a subsample of the validation set (TreeExplainer is exact but scales with n_samples*n_trees)
shap_idx = rng.choice(len(X_val), size=min(3000, len(X_val)), replace=False)
X_shap = X_val[shap_idx]
y_shap = y_val[shap_idx]

explainer = shap.TreeExplainer(rf)
shap_values = explainer.shap_values(X_shap, check_additivity=False)
print("SHAP values type/shape:", type(shap_values), np.array(shap_values).shape if not isinstance(shap_values, list) else [np.array(s).shape for s in shap_values])

# global importance: mean |SHAP| averaged across classes
if isinstance(shap_values, list):
    abs_mean_per_class = np.stack([np.abs(sv).mean(axis=0) for sv in shap_values])  # (n_classes, n_features)
else:
    sv = np.array(shap_values)
    if sv.ndim == 3:
        abs_mean_per_class = np.abs(sv).mean(axis=0).T if sv.shape[0] == len(X_shap) else np.abs(sv).mean(axis=1)
    else:
        abs_mean_per_class = np.abs(sv).mean(axis=0, keepdims=True)

global_importance = abs_mean_per_class.mean(axis=0)
imp_df = pd.DataFrame({"feature": feat_cols, "mean_abs_shap": global_importance}).sort_values(
    "mean_abs_shap", ascending=False)
imp_df.to_csv(os.path.join(RES_DIR, "tables", "T_shap_global_importance.csv"), index=False)
print(imp_df.head(20).to_string())

# classwise importance table
classwise_rows = []
for ci, cname in enumerate(classes):
    for fi, fname in enumerate(feat_cols):
        classwise_rows.append({"class": cname, "feature": fname, "mean_abs_shap": abs_mean_per_class[ci, fi]})
pd.DataFrame(classwise_rows).to_csv(os.path.join(RES_DIR, "tables", "T_shap_classwise_importance.csv"), index=False)

# permutation importance (model-agnostic cross-check against SHAP/MDI ranking)
from sklearn.inspection import permutation_importance
perm = permutation_importance(rf, X_val, y_val, n_repeats=5, random_state=SEED, n_jobs=2, scoring="f1_macro")
perm_df = pd.DataFrame({"feature": feat_cols, "perm_importance_mean": perm.importances_mean,
                         "perm_importance_std": perm.importances_std}).sort_values(
    "perm_importance_mean", ascending=False)
perm_df.to_csv(os.path.join(RES_DIR, "tables", "T_permutation_importance.csv"), index=False)

# native RF (MDI) importance for a third, independent ranking method
mdi_df = pd.DataFrame({"feature": feat_cols, "mdi_importance": rf.feature_importances_}).sort_values(
    "mdi_importance", ascending=False)
mdi_df.to_csv(os.path.join(RES_DIR, "tables", "T_mdi_importance.csv"), index=False)

# rank-correlation across the three independent importance methods (Spearman)
from scipy.stats import spearmanr
merged = imp_df.merge(perm_df, on="feature").merge(mdi_df, on="feature")
rho_shap_perm, _ = spearmanr(merged["mean_abs_shap"], merged["perm_importance_mean"])
rho_shap_mdi, _ = spearmanr(merged["mean_abs_shap"], merged["mdi_importance"])
rho_perm_mdi, _ = spearmanr(merged["perm_importance_mean"], merged["mdi_importance"])
print(f"\nSpearman rho: SHAP-vs-permutation={rho_shap_perm:.3f}, SHAP-vs-MDI={rho_shap_mdi:.3f}, "
      f"permutation-vs-MDI={rho_perm_mdi:.3f}")
with open(os.path.join(RES_DIR, "tables", "importance_method_agreement.json"), "w") as f:
    json.dump({"rho_shap_perm": rho_shap_perm, "rho_shap_mdi": rho_shap_mdi,
                "rho_perm_mdi": rho_perm_mdi}, f, indent=2)

# figure: top-20 global SHAP bar chart
top20 = imp_df.head(20).iloc[::-1]
plt.figure(figsize=(8, 8))
plt.barh(top20["feature"], top20["mean_abs_shap"], color="#4C72B0")
plt.xlabel("Mean |SHAP value| (averaged across classes)")
plt.title("Global feature importance (SHAP, TreeExplainer on Random Forest)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_SHAP_global.png"), dpi=150)
plt.close()

# figure: classwise heatmap of top-15 global features across all 11 classes
top15_feats = imp_df.head(15)["feature"].tolist()
heat = np.zeros((len(classes), len(top15_feats)))
for ci, cname in enumerate(classes):
    for fi, fname in enumerate(top15_feats):
        heat[ci, fi] = abs_mean_per_class[ci, feat_cols.index(fname)]
plt.figure(figsize=(10, 6))
plt.imshow(heat, aspect="auto", cmap="viridis")
plt.colorbar(label="mean |SHAP|")
plt.xticks(range(len(top15_feats)), top15_feats, rotation=90, fontsize=7)
plt.yticks(range(len(classes)), classes, fontsize=8)
plt.title("Class-wise SHAP importance (top-15 global features)")
plt.tight_layout()
plt.savefig(os.path.join(FIG_DIR, "F_SHAP_classwise.png"), dpi=150)
plt.close()

print("\nStage 9 complete: SHAP tables and figures saved.")
