import os, json, time, warnings, sys
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import RobustScaler, LabelEncoder

sys.path.insert(0, os.path.dirname(__file__))
from harness import compute_multiclass_metrics

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print("torch device:", DEVICE)

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
sel = json.load(open(os.path.join(RES_DIR, "tables", "selected_features.json")))
feat_cols = sel["features"]
classes = sel["label_classes"]
n_classes = len(classes)
n_features = len(feat_cols)
le = LabelEncoder(); le.fit(classes)

trainval = df[df["split_role"] == "trainval"].copy()
test_df = df[df["split_role"] == "held_out_test"].copy()
y_tv = le.transform(trainval["label_type"].values)
y_test = le.transform(test_df["label_type"].values)

# single leakage-safe split: CV fold 0 (block-disjoint) as validation, folds 1-4 as train,
# held_out_test (block-disjoint from all of trainval) as the final test set -- consistent with
# the grouped block design built in stage 2
val_mask = trainval["cv_fold"].values == 0
train_mask = ~val_mask

scaler = RobustScaler().fit(trainval.loc[train_mask, feat_cols].values)
# RobustScaler centers/scales by median and IQR but does not bound outliers, and several raw
# N-BaIoT flow-statistics features are extremely heavy-tailed (scaled magnitudes were observed to
# reach ~1e21 on a handful of rows). Unbounded inputs of that scale overflow float32 arithmetic in
# the attention/embedding layers of the transformer, producing inf/nan logits at inference time.
# Clipping the scaled features to a wide but finite range is a standard, documented preprocessing
# safeguard for neural inputs (equivalent in spirit to gradient clipping, but on the input side) and
# does not affect the classical-ML pipeline, which uses its own (unclipped) scaling in stage 4/6b.
CLIP_RANGE = 20.0
def clip_features(X):
    return np.clip(X, -CLIP_RANGE, CLIP_RANGE)

X_train = clip_features(scaler.transform(trainval.loc[train_mask, feat_cols].values)).astype(np.float32)
y_train = y_tv[train_mask]
X_val = clip_features(scaler.transform(trainval.loc[val_mask, feat_cols].values)).astype(np.float32)
y_val = y_tv[val_mask]
X_test = clip_features(scaler.transform(test_df[feat_cols].values)).astype(np.float32)
y_test_arr = y_test

print("train:", X_train.shape, "val:", X_val.shape, "test:", X_test.shape)

class_counts = np.bincount(y_train, minlength=n_classes)
class_weights = (len(y_train) / (n_classes * np.maximum(class_counts, 1))).astype(np.float32)
class_weights_t = torch.tensor(class_weights, device=DEVICE)

def make_loader(X, y, batch_size, shuffle):
    ds = TensorDataset(torch.tensor(X), torch.tensor(y, dtype=torch.long))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, num_workers=0)

train_loader = make_loader(X_train, y_train, 1024, True)
val_loader = make_loader(X_val, y_val, 4096, False)
test_loader = make_loader(X_test, y_test_arr, 4096, False)

class MLP(nn.Module):
    def __init__(self, n_in, n_classes):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_in, 256), nn.ReLU(), nn.BatchNorm1d(256), nn.Dropout(0.2),
            nn.Linear(256, 128), nn.ReLU(), nn.BatchNorm1d(128), nn.Dropout(0.2),
            nn.Linear(128, n_classes)
        )
    def forward(self, x):
        return self.net(x)

class CNN1D(nn.Module):
    def __init__(self, n_in, n_classes):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=5, padding=2), nn.ReLU(), nn.BatchNorm1d(32),
            nn.Conv1d(32, 64, kernel_size=5, padding=2), nn.ReLU(), nn.BatchNorm1d(64),
            nn.AdaptiveAvgPool1d(1)
        )
        self.fc = nn.Sequential(nn.Linear(64, 64), nn.ReLU(), nn.Dropout(0.2), nn.Linear(64, n_classes))
    def forward(self, x):
        x = x.unsqueeze(1)
        x = self.conv(x).squeeze(-1)
        return self.fc(x)

class GRUNet(nn.Module):
    def __init__(self, n_in, n_classes, chunk=4):
        super().__init__()
        self.chunk = chunk
        self.seq_len = int(np.ceil(n_in / chunk))
        self.pad = self.seq_len * chunk - n_in
        self.gru = nn.GRU(input_size=chunk, hidden_size=64, num_layers=1, batch_first=True, bidirectional=True)
        self.fc = nn.Sequential(nn.Linear(128, 64), nn.ReLU(), nn.Dropout(0.2), nn.Linear(64, n_classes))
    def forward(self, x):
        if self.pad > 0:
            x = torch.nn.functional.pad(x, (0, self.pad))
        x = x.view(x.size(0), self.seq_len, self.chunk)
        out, h = self.gru(x)
        last = out[:, -1, :]
        return self.fc(last)

class LiteTransformer(nn.Module):
    def __init__(self, n_in, n_classes, d_model=32, n_heads=4, chunk=4):
        super().__init__()
        self.chunk = chunk
        self.seq_len = int(np.ceil(n_in / chunk))
        self.pad = self.seq_len * chunk - n_in
        self.embed = nn.Linear(chunk, d_model)
        self.pos = nn.Parameter(torch.randn(1, self.seq_len, d_model) * 0.02)
        enc_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=n_heads, dim_feedforward=64,
                                                dropout=0.1, batch_first=True)
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=2)
        self.fc = nn.Sequential(nn.Linear(d_model, 64), nn.ReLU(), nn.Dropout(0.2), nn.Linear(64, n_classes))
    def forward(self, x):
        if self.pad > 0:
            x = torch.nn.functional.pad(x, (0, self.pad))
        x = x.view(x.size(0), self.seq_len, self.chunk)
        x = self.embed(x) + self.pos
        x = self.encoder(x)
        x = x.mean(dim=1)
        return self.fc(x)

MODEL_BUILDERS = {
    "mlp": lambda: MLP(n_features, n_classes),
    "cnn1d": lambda: CNN1D(n_features, n_classes),
    "gru": lambda: GRUNet(n_features, n_classes),
    "lite_transformer": lambda: LiteTransformer(n_features, n_classes),
}

# per-model optimizer settings: the lite transformer is prone to loss blow-up with a flat 1e-3 LR
# and no warmup, so it gets a lower base LR, a short linear warmup, and gradient-norm clipping.
# Gradient clipping is applied to every model as a general safeguard against rare loss spikes.
MODEL_LR = {"mlp": 1e-3, "cnn1d": 1e-3, "gru": 1e-3, "lite_transformer": 2e-4}
MODEL_WARMUP_STEPS = {"mlp": 0, "cnn1d": 0, "gru": 0, "lite_transformer": 200}
GRAD_CLIP_NORM = 1.0

MAX_EPOCHS = 40
PATIENCE = 6

def evaluate(model, loader):
    model.eval()
    all_proba, all_true = [], []
    t0 = time.time()
    with torch.no_grad():
        for xb, yb in loader:
            xb = xb.to(DEVICE)
            logits = model(xb)
            logits = torch.clamp(logits, -30.0, 30.0)  # numerical-stability guard before softmax
            proba = torch.softmax(logits, dim=1).cpu().numpy()
            all_proba.append(proba)
            all_true.append(yb.numpy())
    infer_time = time.time() - t0
    proba = np.concatenate(all_proba)
    y_true = np.concatenate(all_true)
    pred = np.argmax(proba, axis=1)
    return y_true, pred, proba, infer_time

results_rows = []
histories = {}

for name, builder in MODEL_BUILDERS.items():
    print(f"\n=== Training {name} ===")
    model = builder().to(DEVICE)
    base_lr = MODEL_LR.get(name, 1e-3)
    warmup_steps = MODEL_WARMUP_STEPS.get(name, 0)
    opt = torch.optim.Adam(model.parameters(), lr=base_lr, weight_decay=1e-5)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=0.5, patience=2)
    crit = nn.CrossEntropyLoss(weight=class_weights_t)

    best_val_loss = float("inf")
    best_state = {k: v.clone() for k, v in model.state_dict().items()}  # fallback: initial weights
    patience_ctr = 0
    history = []
    diverged = False
    global_step = 0
    t_start = time.time()

    for epoch in range(MAX_EPOCHS):
        model.train()
        train_loss = 0.0
        n_seen = 0
        epoch_had_nan = False
        for xb, yb in train_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            # linear LR warmup (only active for models with warmup_steps > 0, e.g. lite_transformer)
            if warmup_steps > 0 and global_step < warmup_steps:
                warm_lr = base_lr * (global_step + 1) / warmup_steps
                for pg in opt.param_groups:
                    pg["lr"] = warm_lr
            opt.zero_grad()
            logits = model(xb)
            loss = crit(logits, yb)
            if not torch.isfinite(loss):
                epoch_had_nan = True
                opt.zero_grad()
                global_step += 1
                continue
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP_NORM)
            opt.step()
            train_loss += loss.item() * xb.size(0)
            n_seen += xb.size(0)
            global_step += 1
        train_loss = train_loss / n_seen if n_seen > 0 else float("nan")

        model.eval()
        val_loss = 0.0; n_val = 0
        with torch.no_grad():
            for xb, yb in val_loader:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                logits = model(xb)
                loss = crit(logits, yb)
                if torch.isfinite(loss):
                    val_loss += loss.item() * xb.size(0)
                    n_val += xb.size(0)
        val_loss = val_loss / n_val if n_val > 0 else float("nan")
        if warmup_steps == 0 or global_step >= warmup_steps:
            sched.step(val_loss if np.isfinite(val_loss) else best_val_loss)
        history.append({"epoch": epoch, "train_loss": train_loss, "val_loss": val_loss})
        print(f"  epoch {epoch:2d} train_loss={train_loss:.4f} val_loss={val_loss:.4f}", flush=True)

        if not np.isfinite(train_loss) or not np.isfinite(val_loss):
            print(f"  non-finite loss detected at epoch {epoch} -- stopping this model's training "
                  f"(reverting to best/last stable checkpoint)")
            diverged = True
            break

        if val_loss < best_val_loss - 1e-4:
            best_val_loss = val_loss
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            patience_ctr = 0
        else:
            patience_ctr += 1
            if patience_ctr >= PATIENCE:
                print(f"  early stopping at epoch {epoch}")
                break

    train_time = time.time() - t_start
    # best_state always holds a valid dict here (initial weights if no epoch ever improved, e.g.
    # a model that diverged from epoch 0) -- this guard is what previously let a NaN run crash the
    # whole script at model.load_state_dict(None).
    model.load_state_dict(best_state)
    torch.save(best_state, os.path.join(DATA_DIR, f"dl_{name}_best.pt"))
    histories[name] = history

    training_failed = diverged and best_val_loss == float("inf")
    if training_failed:
        # every epoch produced a non-finite loss -- report as a documented training failure rather
        # than silently scoring an untrained (random-init) network as if it were a real result.
        n_test = len(y_test_arr)
        proba = np.full((n_test, n_classes), 1.0 / n_classes, dtype=np.float64)
        pred = np.argmax(proba, axis=1)
        m = compute_multiclass_metrics(y_test_arr, pred, proba, n_classes)
        m["model"] = name
        m["train_time_s"] = train_time
        m["infer_ms_per_1000_rows"] = np.nan
        m["n_params"] = sum(p.numel() for p in model.parameters())
        m["n_epochs_run"] = len(history)
        m["training_status"] = "diverged_nan_loss"
        results_rows.append(m)
        print(f"{name}: TRAINING DIVERGED (non-finite loss from the first epoch) -- recorded as a "
              f"documented negative result, not scored on a meaningful checkpoint.")
        continue

    y_true, pred, proba, infer_time = evaluate(model, test_loader)
    m = compute_multiclass_metrics(y_true, pred, proba, n_classes)
    m["model"] = name
    m["train_time_s"] = train_time
    m["infer_ms_per_1000_rows"] = infer_time / len(y_true) * 1000 * 1000
    m["n_params"] = sum(p.numel() for p in model.parameters())
    m["n_epochs_run"] = len(history)
    m["training_status"] = "diverged_then_stopped_early" if diverged else "converged"
    results_rows.append(m)
    print(f"{name}: MCC={m['mcc']:.4f} F1m={m['f1_macro']:.4f} AUROC={m['auroc_ovr_macro']:.4f} "
          f"params={m['n_params']} epochs={m['n_epochs_run']} train_time={train_time:.1f}s "
          f"status={m['training_status']}")

    np.savez_compressed(os.path.join(DATA_DIR, f"dl_{name}_test_predictions.npz"),
                         y_true=y_true, pred=pred, proba=proba)

res_df = pd.DataFrame(results_rows)
res_df.to_csv(os.path.join(RES_DIR, "tables", "T_deep_learning_results.csv"), index=False)
print("\n=== DEEP LEARNING SUMMARY ===")
print(res_df.to_string())

with open(os.path.join(RES_DIR, "tables", "dl_training_histories.json"), "w") as f:
    json.dump(histories, f, indent=2)

print("Stage 5 complete.")
