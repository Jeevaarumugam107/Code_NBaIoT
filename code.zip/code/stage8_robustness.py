import os, json, time, warnings, sys
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import joblib

sys.path.insert(0, os.path.dirname(__file__))
from harness import compute_multiclass_metrics

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
MODELS_DIR = "/home/claude/iot_botnet_study/results/models"
SEED = 42
rng = np.random.default_rng(SEED)

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
sel = json.load(open(os.path.join(RES_DIR, "tables", "selected_features.json")))
feat_cols = sel["features"]; classes = sel["label_classes"]; n_classes = len(classes)
le = LabelEncoder(); le.fit(classes)

trainval = df[df["split_role"] == "trainval"].copy()
test_df = df[df["split_role"] == "held_out_test"].copy()

val_mask = trainval["cv_fold"].values == 0
train_mask = ~val_mask
y_tv = le.transform(trainval["label_type"].values)
y_train = y_tv[train_mask]; y_val = y_tv[val_mask]

scaler = RobustScaler().fit(trainval.loc[train_mask, feat_cols].values)
X_train = scaler.transform(trainval.loc[train_mask, feat_cols].values)
X_val = scaler.transform(trainval.loc[val_mask, feat_cols].values)

def probe_model():
    return RandomForestClassifier(n_estimators=200, max_depth=16, n_jobs=2, random_state=SEED,
                                   class_weight="balanced")

base_rf = probe_model()
base_rf.fit(X_train, y_train)

rows_robustness = []

def score(y_true, proba, extra=None):
    pred = np.argmax(proba, axis=1)
    m = compute_multiclass_metrics(y_true, pred, proba, n_classes)
    if extra:
        m.update(extra)
    return m

# --- baseline (0% perturbation) ---
proba0 = base_rf.predict_proba(X_val)
m0 = score(y_val, proba0, {"category": "noise_injection_RF", "condition": "0% (baseline)"})
rows_robustness.append(m0)
print(f"[noise 0%] MCC={m0['mcc']:.4f}")

# --- Gaussian noise injection on validation features ---
feat_std = X_train.std(axis=0)
for pct in [0.05, 0.10, 0.25, 0.50, 1.00]:
    X_noisy = X_val + rng.normal(0, 1, size=X_val.shape) * (feat_std * pct)
    proba = base_rf.predict_proba(X_noisy)
    m = score(y_val, proba, {"category": "noise_injection_RF", "condition": f"{int(pct*100)}% of feature std (Gaussian)"})
    rows_robustness.append(m)
    print(f"[noise {int(pct*100)}%] MCC={m['mcc']:.4f}")

# --- same noise sweep for the proposed ensemble (loaded from stage 6b), to compare robustness ---
try:
    cfg = json.load(open(os.path.join(RES_DIR, "tables", "proposed_ensemble_config.json")))
    base_models = cfg["base_models"]
    fitted = {name: joblib.load(os.path.join(MODELS_DIR, f"base_{name}.joblib")) for name in base_models}
    meta = joblib.load(os.path.join(MODELS_DIR, "meta_learner.joblib"))

    def ensemble_proba(X):
        parts = []
        for name in base_models:
            mdl = fitted[name]
            pp = mdl.predict_proba(X)
            mc = getattr(mdl, "classes_", np.arange(n_classes))
            full = np.zeros((X.shape[0], n_classes))
            for ci, c in enumerate(mc):
                full[:, int(c)] = pp[:, ci]
            parts.append(full)
        X_stack = np.concatenate(parts, axis=1)
        mp = meta.predict_proba(X_stack)
        out = np.zeros((X.shape[0], n_classes))
        for ci, c in enumerate(meta.classes_):
            out[:, int(c)] = mp[:, ci]
        return out

    proba0_ens = ensemble_proba(X_val)
    m0e = score(y_val, proba0_ens, {"category": "noise_injection_proposed_ensemble", "condition": "0% (baseline)"})
    rows_robustness.append(m0e)
    for pct in [0.05, 0.10, 0.25, 0.50, 1.00]:
        X_noisy = X_val + rng.normal(0, 1, size=X_val.shape) * (feat_std * pct)
        proba = ensemble_proba(X_noisy)
        m = score(y_val, proba, {"category": "noise_injection_proposed_ensemble",
                                  "condition": f"{int(pct*100)}% of feature std (Gaussian)"})
        rows_robustness.append(m)
        print(f"[ensemble noise {int(pct*100)}%] MCC={m['mcc']:.4f}")
except FileNotFoundError:
    print("Proposed ensemble artifacts not found yet -- run stage6b first. Skipping ensemble noise sweep.")

# --- missing-feature simulation (median imputation) ---
medians = np.median(X_train, axis=0)
for pct in [0.10, 0.25, 0.50, 0.75]:
    X_missing = X_val.copy()
    mask = rng.random(X_missing.shape) < pct
    X_missing[mask] = np.take(medians, np.where(mask)[1])
    proba = base_rf.predict_proba(X_missing)
    m = score(y_val, proba, {"category": "missing_features_RF", "condition": f"{int(pct*100)}% values missing (median-imputed)"})
    rows_robustness.append(m)
    print(f"[missing {int(pct*100)}%] MCC={m['mcc']:.4f}")

# --- training-size sweep ---
for frac in [0.10, 0.25, 0.50, 0.75, 1.00]:
    n = int(len(y_train) * frac)
    idx = rng.choice(len(y_train), size=n, replace=False)
    mdl = probe_model()
    mdl.fit(X_train[idx], y_train[idx])
    proba = mdl.predict_proba(X_val)
    m = score(y_val, proba, {"category": "training_size", "condition": f"{int(frac*100)}% of training data"})
    rows_robustness.append(m)
    print(f"[trainsize {int(frac*100)}%] MCC={m['mcc']:.4f}")

# --- class imbalance sweep: vary benign:attack ratio in the training pool by subsampling attack rows ---
benign_class_idx = list(le.classes_).index("benign")
is_benign_train = (y_train == benign_class_idx)
n_benign = is_benign_train.sum()
n_attack = (~is_benign_train).sum()
for target_attack_rate in [0.50, 0.70, 0.80, 0.90, float(n_attack) / (n_attack + n_benign)]:
    target_attack_rate = min(target_attack_rate, 0.98)
    n_benign_keep = n_benign
    n_attack_keep = int(n_benign_keep * target_attack_rate / (1 - target_attack_rate))
    n_attack_keep = min(n_attack_keep, n_attack)
    benign_idx = np.where(is_benign_train)[0]
    attack_idx = rng.choice(np.where(~is_benign_train)[0], size=n_attack_keep, replace=False)
    idx = np.concatenate([benign_idx, attack_idx])
    mdl = probe_model()
    mdl.fit(X_train[idx], y_train[idx])
    proba = mdl.predict_proba(X_val)
    actual_rate = n_attack_keep / (n_attack_keep + n_benign_keep)
    m = score(y_val, proba, {"category": "class_imbalance", "condition": f"train attack rate={actual_rate*100:.1f}%"})
    rows_robustness.append(m)
    print(f"[imbalance attack_rate={actual_rate:.2f}] MCC={m['mcc']:.4f}")

pd.DataFrame(rows_robustness).to_csv(os.path.join(RES_DIR, "tables", "T_robustness.csv"), index=False)
print("\nSaved T_robustness.csv")

# --- cross-device generalization: leave-one-device-out, using the full sampled pool (trainval+test) ---
full_scaled_all = scaler.transform(df[feat_cols].values)
y_all = le.transform(df["label_type"].values)
devices = sorted(df["device"].unique())
device_rows = []
for held_out_device in devices:
    is_held = (df["device"].values == held_out_device)
    Xtr = full_scaled_all[~is_held]; ytr = y_all[~is_held]
    Xte = full_scaled_all[is_held]; yte = y_all[is_held]
    mdl = probe_model()
    mdl.fit(Xtr, ytr)
    proba = mdl.predict_proba(Xte)
    mc = getattr(mdl, "classes_", np.arange(n_classes))
    proba_full = np.zeros((len(yte), n_classes))
    for ci, c in enumerate(mc):
        proba_full[:, int(c)] = proba[:, ci]
    pred = np.argmax(proba_full, axis=1)
    m = compute_multiclass_metrics(yte, pred, proba_full, n_classes)
    m["category"] = "cross_device"; m["condition"] = f"held-out device: {held_out_device}"
    m["n_test"] = len(yte)
    device_rows.append(m)
    print(f"[cross-device {held_out_device}] MCC={m['mcc']:.4f} n_test={len(yte)}")

pd.DataFrame(device_rows).to_csv(os.path.join(RES_DIR, "tables", "T_cross_device_generalization.csv"), index=False)

# --- cross-attack-type (zero-day) generalization: leave-one-attack-subtype-out ---
attack_types = [c for c in le.classes_ if c != "benign"]
scenario_rows = []
for held_out_type in attack_types:
    held_class_idx = list(le.classes_).index(held_out_type)
    is_held_rows = (y_all == held_class_idx)
    Xtr = full_scaled_all[~is_held_rows]; ytr = y_all[~is_held_rows]
    Xte_attack = full_scaled_all[is_held_rows]  # the held-out attack subtype, never seen in training
    mdl = probe_model()
    mdl.fit(Xtr, ytr)
    proba = mdl.predict_proba(Xte_attack)
    mc = getattr(mdl, "classes_", np.arange(n_classes))
    proba_full = np.zeros((is_held_rows.sum(), n_classes))
    for ci, c in enumerate(mc):
        proba_full[:, int(c)] = proba[:, ci]
    pred = np.argmax(proba_full, axis=1)
    # "recall" here = fraction of the truly-unseen attack subtype's rows classified as ANY attack
    # class (not benign) -- the model was never trained on this class at all, so it cannot predict
    # its exact label; this measures whether the anomaly is still flagged as non-benign.
    benign_idx = list(le.classes_).index("benign")
    flagged_as_attack = (pred != benign_idx)
    unseen_recall = flagged_as_attack.mean()
    scenario_rows.append({"category": "cross_scenario", "condition": f"held-out attack category: {held_out_type}",
                           "n_test": int(is_held_rows.sum()), "unseen_category_flagged_as_attack_rate": unseen_recall})
    print(f"[zero-day {held_out_type}] flagged-as-attack rate={unseen_recall:.4f} n_test={is_held_rows.sum()}")

pd.DataFrame(scenario_rows).to_csv(os.path.join(RES_DIR, "tables", "T_cross_scenario_generalization.csv"), index=False)

print("\nStage 8 complete.")
