import os, hashlib
import numpy as np
import pandas as pd

RAW_ROOT = "/home/claude/nbaiot_raw"
OUT_DIR = "/home/claude/iot_botnet_study/data"
RESULTS_DIR = "/home/claude/iot_botnet_study/results"
SEED = 42
BLOCK_SIZE = 500
CAP_ROWS_PER_FILE = 3000

rng = np.random.default_rng(SEED)

devices = sorted([d for d in os.listdir(RAW_ROOT) if os.path.isdir(os.path.join(RAW_ROOT, d))])
print("Devices:", devices)

# build the list of (device, family, subtype, relative_path) to walk, now that mirai/gafgyt
# are extracted into separate subfolders so there is no scan.csv / udp.csv filename collision
file_specs = []
for device in devices:
    ddir = os.path.join(RAW_ROOT, device)
    benign_path = os.path.join(ddir, "benign_traffic.csv")
    if os.path.exists(benign_path):
        file_specs.append((device, "benign", "benign", benign_path))
    for family in ["mirai", "gafgyt"]:
        fam_dir = os.path.join(ddir, family)
        if os.path.isdir(fam_dir):
            for fname in sorted(os.listdir(fam_dir)):
                if fname.endswith(".csv"):
                    subtype = fname.replace(".csv", "")
                    file_specs.append((device, family, subtype, os.path.join(fam_dir, fname)))

print(f"Total files to load: {len(file_specs)}")

inventory_rows = []
sampled_frames = []

for device, family, subtype, path in file_specs:
    df = pd.read_csv(path)
    n_full = len(df)
    n_cols = df.shape[1]

    label_binary = "benign" if family == "benign" else "attack"
    label_family = family
    label_type = "benign" if family == "benign" else f"{family}_{subtype}"

    with open(path, "rb") as fh:
        md5 = hashlib.md5(fh.read()).hexdigest()

    inventory_rows.append({
        "device": device, "source_path": os.path.relpath(path, RAW_ROOT), "n_rows_full": n_full,
        "n_cols": n_cols, "label_binary": label_binary,
        "label_family": label_family, "label_type": label_type, "md5": md5
    })

    n_blocks = n_full // BLOCK_SIZE
    block_ids = np.arange(n_blocks)
    target_blocks = max(1, CAP_ROWS_PER_FILE // BLOCK_SIZE)
    if n_blocks <= target_blocks:
        chosen_blocks = block_ids
    else:
        chosen_blocks = rng.choice(block_ids, size=target_blocks, replace=False)
        chosen_blocks.sort()

    idx = []
    for b in chosen_blocks:
        start = b * BLOCK_SIZE
        idx.extend(range(start, start + BLOCK_SIZE))

    sample_df = df.iloc[idx].copy()
    sample_df["device"] = device
    sample_df["source_path"] = os.path.relpath(path, RAW_ROOT)
    sample_df["label_binary"] = label_binary
    sample_df["label_family"] = label_family
    sample_df["label_type"] = label_type
    sample_df["block_id"] = [f"{device}__{family}__{subtype}__{(i // BLOCK_SIZE)}" for i in idx]
    sampled_frames.append(sample_df)
    print(f"{device:45s} {family:8s} {subtype:12s} full={n_full:7d} sampled={len(sample_df):6d}")

inv_df = pd.DataFrame(inventory_rows)
os.makedirs(os.path.join(RESULTS_DIR, "tables"), exist_ok=True)
inv_df.to_csv(os.path.join(RESULTS_DIR, "tables", "dataset_inventory.csv"), index=False)

full = pd.concat(sampled_frames, ignore_index=True)
print("\nTOTAL SAMPLED ROWS:", len(full))
print("\nBy label_family:\n", full["label_family"].value_counts())
print("\nBy label_type:\n", full["label_type"].value_counts())
print("\nBy device:\n", full["device"].value_counts())
print("\nDuplicate rows (feature columns only):",
      full.drop(columns=["device","source_path","label_binary","label_family","label_type","block_id"]).duplicated().sum())
print("Any missing values:", full.isna().sum().sum())

os.makedirs(OUT_DIR, exist_ok=True)
full.to_pickle(os.path.join(OUT_DIR, "sampled_raw.pkl"))
print("Saved to", os.path.join(OUT_DIR, "sampled_raw.pkl"))
print("TOTAL FULL-POPULATION ROWS (all 9 devices, all files):", inv_df["n_rows_full"].sum())
