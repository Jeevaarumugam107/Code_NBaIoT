import os, json, time, warnings, sys
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC, LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, HistGradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
import xgboost as xgb
import lightgbm as lgb
import catboost as cb

sys.path.insert(0, os.path.dirname(__file__))
from harness import compute_multiclass_metrics

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
SEED = 42
RBF_SVM_TRAIN_CAP = 12000
KNN_TRAIN_CAP = 40000

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
sel = json.load(open(os.path.join(RES_DIR, "tables", "selected_features.json")))
feat_cols = sel["features"]
classes = sel["label_classes"]
n_classes = len(classes)
le = LabelEncoder(); le.fit(classes)

trainval = df[df["split_role"] == "trainval"].copy()
y_tv = le.transform(trainval["label_type"].values)
groups = trainval["block_id"].values

def get_model(name, seed):
    if name == "logistic_regression":
        return LogisticRegression(max_iter=500, n_jobs=2, random_state=seed, class_weight="balanced")
    if name == "linear_svm":
        base = LinearSVC(max_iter=3000, random_state=seed, class_weight="balanced")
        return CalibratedClassifierCV(base, method="sigmoid", cv=3)
    if name == "rbf_svm":
        return SVC(kernel="rbf", probability=True, random_state=seed, class_weight="balanced")
    if name == "random_forest":
        return RandomForestClassifier(n_estimators=300, max_depth=18, n_jobs=2, random_state=seed, class_weight="balanced")
    if name == "extra_trees":
        return ExtraTreesClassifier(n_estimators=300, max_depth=18, n_jobs=2, random_state=seed, class_weight="balanced")
    if name == "xgboost":
        return xgb.XGBClassifier(n_estimators=300, max_depth=8, learning_rate=0.1, n_jobs=2,
                                  random_state=seed, eval_metric="mlogloss", tree_method="hist")
    if name == "lightgbm":
        return lgb.LGBMClassifier(n_estimators=300, num_leaves=63, random_state=seed,
                                   class_weight="balanced", verbosity=-1, n_jobs=2)
    if name == "catboost":
        return cb.CatBoostClassifier(iterations=300, depth=8, random_state=seed, verbose=False,
                                      auto_class_weights="Balanced", thread_count=2)
    if name == "histgradientboosting":
        return HistGradientBoostingClassifier(max_iter=300, max_depth=10, random_state=seed, class_weight="balanced")
    if name == "knn":
        return KNeighborsClassifier(n_neighbors=7, n_jobs=2)
    raise ValueError(name)

MODEL_NAMES = ["logistic_regression", "linear_svm", "rbf_svm", "random_forest", "extra_trees",
               "xgboost", "lightgbm", "catboost", "histgradientboosting", "knn"]

fold_ids = sorted(trainval["cv_fold"].unique())
all_fold_metrics = []
oof_predictions = {name: np.full(len(trainval), -1, dtype=int) for name in MODEL_NAMES}
oof_proba = {name: np.zeros((len(trainval), n_classes)) for name in MODEL_NAMES}
timing_rows = []

rng = np.random.default_rng(SEED)

for fold in fold_ids:
    val_mask = (trainval["cv_fold"].values == fold)
    tr_mask = ~val_mask
    X_tr = trainval.loc[tr_mask, feat_cols].values
    y_tr = y_tv[tr_mask]
    X_val = trainval.loc[val_mask, feat_cols].values
    y_val = y_tv[val_mask]

    scaler = RobustScaler().fit(X_tr)
    X_tr_s = scaler.transform(X_tr)
    X_val_s = scaler.transform(X_val)

    for name in MODEL_NAMES:
        X_tr_use, y_tr_use = X_tr_s, y_tr
        if name == "rbf_svm" and len(y_tr) > RBF_SVM_TRAIN_CAP:
            idx = rng.choice(len(y_tr), size=RBF_SVM_TRAIN_CAP, replace=False)
            X_tr_use, y_tr_use = X_tr_s[idx], y_tr[idx]
        if name == "knn" and len(y_tr) > KNN_TRAIN_CAP:
            idx = rng.choice(len(y_tr), size=KNN_TRAIN_CAP, replace=False)
            X_tr_use, y_tr_use = X_tr_s[idx], y_tr[idx]

        model = get_model(name, SEED + fold)
        t0 = time.time()
        model.fit(X_tr_use, y_tr_use)
        fit_time = time.time() - t0

        t0 = time.time()
        proba_pred = model.predict_proba(X_val_s)
        model_classes = getattr(model, "classes_", np.arange(n_classes))
        proba_full = np.zeros((len(y_val), n_classes))
        for ci, c in enumerate(model_classes):
            proba_full[:, int(c)] = proba_pred[:, ci]
        infer_time_s = time.time() - t0

        pred = np.argmax(proba_full, axis=1)
        m = compute_multiclass_metrics(y_val, pred, proba_full, n_classes)
        m["model"] = name; m["fold"] = int(fold)
        m["fit_time_s"] = fit_time
        m["infer_ms_per_1000_rows"] = infer_time_s / len(y_val) * 1000 * 1000
        all_fold_metrics.append(m)

        val_global_idx = np.where(val_mask)[0]
        oof_predictions[name][val_global_idx] = pred
        oof_proba[name][val_global_idx] = proba_full

        timing_rows.append({"model": name, "fold": int(fold), "fit_time_s": fit_time,
                             "infer_time_s": infer_time_s,
                             "n_train": len(y_tr_use), "n_val": len(y_val)})

        print(f"fold={fold} model={name:22s} MCC={m['mcc']:.4f} F1m={m['f1_macro']:.4f} "
              f"AUROC={m['auroc_ovr_macro']:.4f} fit={fit_time:.1f}s", flush=True)

metrics_df = pd.DataFrame(all_fold_metrics)
metrics_df.to_csv(os.path.join(RES_DIR, "tables", "T_classical_ml_fold_results.csv"), index=False)
pd.DataFrame(timing_rows).to_csv(os.path.join(RES_DIR, "tables", "T_classical_ml_timing.csv"), index=False)

summary = metrics_df.groupby("model").agg(
    accuracy_mean=("accuracy","mean"), accuracy_std=("accuracy","std"),
    precision_mean=("precision_macro","mean"), precision_std=("precision_macro","std"),
    recall_mean=("recall_macro","mean"), recall_std=("recall_macro","std"),
    f1_mean=("f1_macro","mean"), f1_std=("f1_macro","std"),
    balanced_accuracy_mean=("balanced_accuracy","mean"), balanced_accuracy_std=("balanced_accuracy","std"),
    mcc_mean=("mcc","mean"), mcc_std=("mcc","std"),
    auroc_mean=("auroc_ovr_macro","mean"), auroc_std=("auroc_ovr_macro","std"),
    auprc_mean=("auprc_ovr_macro","mean"), auprc_std=("auprc_ovr_macro","std"),
    logloss_mean=("log_loss","mean"), logloss_std=("log_loss","std"),
    brier_mean=("brier_score","mean"), brier_std=("brier_score","std"),
).reset_index().sort_values("mcc_mean", ascending=False)
summary.to_csv(os.path.join(RES_DIR, "tables", "T_classical_ml_summary.csv"), index=False)
print("\n=== SUMMARY (sorted by MCC) ===")
print(summary.to_string())

np.savez_compressed(os.path.join(DATA_DIR, "classical_oof.npz"),
                     **{f"pred_{k}": v for k, v in oof_predictions.items()},
                     **{f"proba_{k}": v for k, v in oof_proba.items()},
                     y_true=y_tv, cv_fold=trainval["cv_fold"].values)
print("Saved OOF predictions.")
