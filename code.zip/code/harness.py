import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                              balanced_accuracy_score, matthews_corrcoef, roc_auc_score,
                              average_precision_score, log_loss, brier_score_loss)
from sklearn.preprocessing import label_binarize

def compute_multiclass_metrics(y_true, y_pred, proba, n_classes, labels=None):
    out = {}
    out["accuracy"] = accuracy_score(y_true, y_pred)
    out["precision_macro"] = precision_score(y_true, y_pred, average="macro", zero_division=0)
    out["recall_macro"] = recall_score(y_true, y_pred, average="macro", zero_division=0)
    out["f1_macro"] = f1_score(y_true, y_pred, average="macro", zero_division=0)
    out["balanced_accuracy"] = balanced_accuracy_score(y_true, y_pred)
    out["mcc"] = matthews_corrcoef(y_true, y_pred)
    yb = label_binarize(y_true, classes=list(range(n_classes)))
    try:
        out["auroc_ovr_macro"] = roc_auc_score(yb, proba, average="macro", multi_class="ovr")
    except Exception:
        out["auroc_ovr_macro"] = np.nan
    try:
        out["auprc_ovr_macro"] = average_precision_score(yb, proba, average="macro")
    except Exception:
        out["auprc_ovr_macro"] = np.nan
    try:
        out["log_loss"] = log_loss(y_true, proba, labels=list(range(n_classes)))
    except Exception:
        out["log_loss"] = np.nan
    # multiclass Brier score (mean squared error between one-hot and predicted proba)
    try:
        out["brier_score"] = np.mean(np.sum((yb - proba) ** 2, axis=1))
    except Exception:
        out["brier_score"] = np.nan
    return out
