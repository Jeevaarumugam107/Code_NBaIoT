import os, json, time
import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
from sklearn.metrics import roc_auc_score, matthews_corrcoef, f1_score
from sklearn.model_selection import GroupShuffleSplit

DATA_DIR = "/home/claude/iot_botnet_study/data"
RES_DIR = "/home/claude/iot_botnet_study/results"
SEED = 42

df = pd.read_pickle(os.path.join(DATA_DIR, "sampled_with_folds.pkl"))
feat_cols = json.load(open(os.path.join(RES_DIR, "tables", "feature_columns.json")))
corr = pd.read_csv(os.path.join(RES_DIR, "tables", "T_feature_correlation_matrix.csv"), index_col=0)

trainval = df[df["split_role"] == "trainval"].copy()
le = LabelEncoder()
y_all_labels = sorted(df["label_type"].unique())
le.fit(y_all_labels)
y_tv = le.transform(trainval["label_type"].values)
print("Classes:", list(le.classes_))

rng = np.random.default_rng(SEED)
mi_sub_idx = rng.choice(len(trainval), size=min(40000, len(trainval)), replace=False)
X_mi = trainval.iloc[mi_sub_idx][feat_cols].values
y_mi = y_tv[mi_sub_idx]

t0 = time.time()
mi = mutual_info_classif(X_mi, y_mi, random_state=SEED, n_neighbors=3)
print(f"MI (multiclass) computed in {time.time()-t0:.1f}s")
mi_series = pd.Series(mi, index=feat_cols).sort_values(ascending=False)

t0 = time.time()
rf = RandomForestClassifier(n_estimators=150, max_depth=14, n_jobs=2, random_state=SEED, class_weight="balanced")
rf.fit(X_mi, y_mi)
print(f"RF importance (multiclass) computed in {time.time()-t0:.1f}s")
rf_series = pd.Series(rf.feature_importances_, index=feat_cols).sort_values(ascending=False)

rank_df = pd.DataFrame({
    "feature": feat_cols,
    "mi_score": mi_series.reindex(feat_cols).values,
    "mi_rank": mi_series.reindex(feat_cols).rank(ascending=False).values,
    "rf_importance": rf_series.reindex(feat_cols).values,
    "rf_rank": rf_series.reindex(feat_cols).rank(ascending=False).values,
})
rank_df["combined_rank"] = rank_df["mi_rank"] + rank_df["rf_rank"]
rank_df = rank_df.sort_values("combined_rank")
rank_df.to_csv(os.path.join(RES_DIR, "tables", "T_feature_ranking_multiclass.csv"), index=False)
print(rank_df.head(15).to_string())

kept = []
dropped_redundant = []
for f in rank_df["feature"]:
    is_redundant = False
    for k in kept:
        if abs(corr.loc[f, k]) >= 0.98:
            is_redundant = True
            dropped_redundant.append((f, k, corr.loc[f, k]))
            break
    if not is_redundant:
        kept.append(f)
print(f"\nAfter redundancy pruning: {len(kept)} / {len(feat_cols)} features kept")
pd.DataFrame(dropped_redundant, columns=["dropped_feature","kept_correlated_with","corr"]).to_csv(
    os.path.join(RES_DIR, "tables", "T_redundancy_pruning_multiclass.csv"), index=False)

gss = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=SEED)
inner_tr_idx, inner_val_idx = next(gss.split(trainval, y_tv, groups=trainval["block_id"].values))
inner_tr = trainval.iloc[inner_tr_idx]; inner_val = trainval.iloc[inner_val_idx]
y_inner_tr = y_tv[inner_tr_idx]; y_inner_val = y_tv[inner_val_idx]

Ks = [5, 8, 10, 15, 20, 25, 30, 40, 50, len(kept)]
sweep_rows = []
for K in sorted(set(min(k, len(kept)) for k in Ks)):
    cols = kept[:K]
    clf = lgb.LGBMClassifier(n_estimators=200, num_leaves=31, random_state=SEED,
                              class_weight="balanced", verbosity=-1, n_jobs=2)
    t0 = time.time()
    clf.fit(inner_tr[cols].values, y_inner_tr)
    fit_time = time.time() - t0
    t0 = time.time()
    proba = clf.predict_proba(inner_val[cols].values)
    infer_time = (time.time() - t0) / len(inner_val) * 1000
    pred = np.argmax(proba, axis=1)
    try:
        auroc = roc_auc_score(y_inner_val, proba, multi_class="ovr", average="macro")
    except Exception as e:
        auroc = np.nan
    mcc = matthews_corrcoef(y_inner_val, pred)
    f1m = f1_score(y_inner_val, pred, average="macro")
    sweep_rows.append({"k_features": K, "auroc_ovr_macro": auroc, "mcc": mcc, "f1_macro": f1m,
                        "fit_time_s": fit_time, "infer_ms_per_row": infer_time})
    print(f"K={K:4d}  AUROC_ovr={auroc:.4f}  MCC={mcc:.4f}  F1_macro={f1m:.4f}  fit={fit_time:.1f}s")

sweep_df = pd.DataFrame(sweep_rows)
sweep_df.to_csv(os.path.join(RES_DIR, "tables", "T_feature_count_sweep_multiclass.csv"), index=False)

best_mcc = sweep_df["mcc"].max()
candidates = sweep_df[sweep_df["mcc"] >= best_mcc - 0.01].sort_values("k_features")
knee_K = int(candidates.iloc[0]["k_features"])
print(f"\nBest MCC={best_mcc:.4f}; knee-point K = {knee_K}")

final_features = kept[:knee_K]
with open(os.path.join(RES_DIR, "tables", "selected_features.json"), "w") as f:
    json.dump({"knee_K": knee_K, "features": final_features, "label_classes": list(le.classes_)}, f, indent=2)
print("Selected features:", final_features)
